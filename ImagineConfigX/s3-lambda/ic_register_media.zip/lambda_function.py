import os
import re
import json
import logging
from decimal import Decimal
import boto3
from botocore.client import Config
from botocore.exceptions import ClientError
import urllib3
from pymediainfo import MediaInfo
import base64
import requests
from requests.auth import HTTPBasicAuth



logging_level = os.getenv("LOGGING", logging.INFO)
logger = logging.getLogger()
logger.setLevel(logging_level)
logging.getLogger("boto3").setLevel(logging_level)
logging.getLogger("botocore").setLevel(logging.CRITICAL)
logging.getLogger("urllib3").setLevel(logging.CRITICAL)

def lambda_handler(event, context):
  
  logger.info(event)
  for rec in event["Records"]:
    register_media(
      rec["s3"]["bucket"]["name"],
      rec["s3"]["object"]["key"]
      )

def get_secret():

    secret_name = os.getenv("SECRET_NAME")
    region_name = os.environ['AWS_REGION']

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        logger.info("Requesting secret")
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            raise e
    else:
        # Decrypts secret using the associated KMS CMK.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']

        else:
            decoded_binary_secret = base64.b64decode(get_secret_value_response['SecretBinary'])
    
    return json.loads(secret)
    
def get_client_secret(aws_secret, client_name):
  #connect to hermes and pull client data
  url = f"http://{aws_secret['coreServicesHost']}:9872/api/config/text/secrets.auth.config.json"
  headers = {'content-type':'application/json'}
  
  response = req_get(url,headers)
  client_secrets = json.loads(response.text)
  
  clientList = client_secrets["clientAuthenticators"]
  for client in clientList:
    if(client["id"]==client_name):
      secretKey = client["secretKey"]
  
  logger.info(secretKey)
  return secretKey

def get_auth_token(keycloak_host,secret_key):
  
  payload = 'grant_type=client_credentials&scope=content-service.content.read content-service.content.write content-service.configuration.read'
  url = f"http://{keycloak_host}:8081/auth/realms/Versio/protocol/openid-connect/token"
  headers = {'content-type':'application/x-www-form-urlencoded'}
  
  response = req_post(url,payload.encode('utf-8'),headers,'content-service',secret_key)
  
  t = json.loads(response.text)
  token = t["access_token"]
  logger.info(token)
  return token

def req_post(url,data,headers,user,password):

  try:
    response = requests.post(
      url = url,
      data = data,
      headers = headers,
      auth =HTTPBasicAuth(user,password)
    )
  except requests.exceptions.RequestException as e:  
    logger.error(f"ERROR: An Error has occured, likely could not connect to host: {url}")    
    raise SystemExit(e)
    
  return response

def req_get(url,headers):

  try:
    response = requests.get(
      url,
      headers = headers,
    )
  except requests.exceptions.RequestException as e:  
    logger.error("ERROR: An Error has occured, likely could not connect to host")    
    raise SystemExit(e)
    
  return response

def is_auth_enabled():
  
  key_value = os.getenv("AUTH_ENABLED")
  auth_enabled = False
  
  if key_value == "true":
    auth_enabled = True
  elif key_value == "false":
    auth_enabled = False
  else:
    logger.error(f"Cannot covert AUTH_ENABLED value: {key_value} must be true or false, defaulting to: {auth_enabled}")
    raise ValueError(f"Cannot covert AUTH_ENABLED value: {key_value} must be true or false, defaulting to: {auth_enabled}")
    
  return auth_enabled
  
def register_media(bucket, key):
  media_uri = f"s3://{bucket}/{key}"
  logger.info(f"S3 Uri: {media_uri}")
  token = ""
  
  if is_auth_enabled():
    logger.info("Authentication is set to true")
    aws_secret = get_secret()
    client_secret = get_client_secret(aws_secret,"content-service")
    token = get_auth_token(aws_secret['keycloakHost'],client_secret)
  else:
    logger.info("Authentication is set to false")
  
  # Split path and filename
  media_path, media_name = os.path.split(key)
  media_id = os.path.splitext(media_name)[0]

  # Purge lowres copy if exists
  purge_lowres(os.getenv("S3BUCKET_LOWRES"), media_id)
      
  # Extract fields from mediainfo
  som, frame_count, file_size, width, height, bit_rate, frame_rate = extract_mediainfo(bucket, key)
  f_frame_rate = float(frame_rate)
  logger.info("framerate: "+frame_rate)
  drop_frame = False

  
  if f_frame_rate==25.00:
    dur = pal_frames_to_tc(frame_count)
    s_frame_rate = "smpte25"
    
    
  # Force som/dur to drop frame
  # Supports only 29.97/30
  if f_frame_rate > 25.00:
    logger.info("30fps")
    frame_rate = 30
    #s_frame_rate = "smpte30d"
    s_frame_rate = "smpte25"
    dur = frames_to_tc(frame_count, True, frame_rate)
    drop_frame = is_dropframe(som)
    if not drop_frame:
      logger.info("Non drop frame ")
      som = frames_to_tc(tc_to_frames(som, False, frame_rate), True, frame_rate)

  # Correct format for content portal
  if f_frame_rate==25.00:
    som = f"{som}%00SP"
    dur = f"{dur}%00SP"
  else:
    som = f"{som}%00SD"
    dur = f"{dur}%00SD"
  
  logger.info("dur: "+dur)
  logger.info("som: "+som)

  # Map to Content service JSON
  logger.debug("Mapping to content")
  content = get_content(
        houseId=media_id, 
        title=media_id,
        fileName=media_id,
        som=som,
        dur=dur,
        fileSize=file_size,
        bitRate=bit_rate,
        s3uri=media_uri,
        width=width,
        height=height,
        frameRate=s_frame_rate
        )
  logger.debug(f"Content: {json.dumps(content)}")

  # Check if Filename already exists
  content_id = search_content(media_id,token)
  logger.debug(f"Content found: {content_id}")

  # Post/Patch content service
  post_content(content, content_id, token)

  # Create lowres proxy invoking a lambda
  client_lambda = boto3.client('lambda')
  client_lambda.invoke(FunctionName=os.getenv("LAMBDA_LOWRES"),
        InvocationType='Event',
        Payload=json.dumps({"bucket":bucket, "key":key, "dropFrame":drop_frame}))

def extract_mediainfo(bucket, key):
  # Create a URL pointer to the file
  signed_url = get_signed_url(bucket, key)
  logger.debug(f"Signed URL: {signed_url}")
        
  # Extract Media Info from the url
  mi = MediaInfo.parse(signed_url, library_file='/opt/libmediainfo.so.0')
  logger.debug(f"MediaInfo: {json.dumps(mi.to_json())}")

  som_smpte = None
  # Grab the fields that matter
  for track in mi.tracks:
    if track.track_type == "General":
      file_size = track.file_size
      frame_rate = track.frame_rate
      frame_count = int(track.frame_count)
    if track.track_type == "Video":
      width = track.width
      height = track.height
      aspect_ratio = track.display_aspect_ratio
      bit_rate = track.bit_rate
    if track.track_type == "Other" and track.format == "MXF TC":
      som_mxf = track.time_code_of_first_frame
    if track.track_type == "Other" and track.format == "SMPTE TC":
      som_smpte = track.time_code_of_first_frame
  som = som_smpte if som_smpte is not None else som_mxf

  return som, frame_count, file_size, width, height, bit_rate, frame_rate


def purge_lowres(bucket, media_id):
  config = Config(connect_timeout=10, retries={'max_attempts': 0})
  client = boto3.client('s3', config=config)
  prefix = f"{media_id}/stream"
  response = client.list_objects_v2(Bucket=bucket, Prefix=prefix)
  logger.debug(response)
  if "Contents" in response:
    for content in response["Contents"]:
      msg = content["Key"]
      msg = f"About to delete S3 {bucket} object {msg}"
      logger.debug(msg)
      client.delete_object(Bucket=bucket, Key=content["Key"])
      
def search_content(fileName, token):
  try:
    url = os.getenv("ENDPOINT_CONTENTSERVICE")
    url = f"{url}?fileName={fileName}"
    logger.debug(f"Content search URL: {url}")
    
    if is_auth_enabled():
      headers = {
      'content-type': 'application/json',
      'authorization' : 'bearer {}'.format(token)
      }
    else:
      headers = {'content-type': 'application/json'}
    
    http = urllib3.PoolManager()
    r = http.request('GET', 
                      url, 
                      headers=headers
                    )
    
    logger.info("Search content returned Status Code: " +str(r.status))
    data = json.loads(r.data.decode('utf-8'))
    logger.debug(f"Content search response: {data}")
    if data["metadata"]["resultset"]["count"] > 0:
      return data["results"][0]["id"]  
    else:
      return None

  except Exception as err:
    msg = f"search-content failed: {err}"
    logger.info("Return Status Code: " +str(r.status))
    logger.critical(msg)
    raise Exception(msg)

def post_content(content, id, token):
  
  logger.debug(f"Post Content: Content {content} id: {id} token: {token}")
  
  try:
    url = os.getenv("ENDPOINT_CONTENTSERVICE")
    verb = "POST"
    if id is not None:
      verb = "PATCH"
      url = f"{url}/{id}"
      logger.debug(f"patch url: {url}")
      content["id"] = id
    
    body = json.dumps(content)

    if is_auth_enabled():
      headers = {
      'content-type': 'application/json',
      'authorization' : 'bearer {}'.format(token)
      }
    else:
      headers = {'content-type': 'application/json'}
    
    http = urllib3.PoolManager()
    r = http.request(verb, url, body=body.encode('utf-8'), headers=headers)
    data = r.data.decode('utf-8')
    status = str(r.status) 
    logger.info(f"{verb} command returned status code: {status} {data}")

    #return data      #commented as no return expected on calling function  

  except Exception as err:
    msg = f"Post Content failed: {err}"
    logger.critical(msg)
    raise Exception(msg)

def get_signed_url(bucket, obj):
  s3_client = boto3.client('s3')
  presigned_url = s3_client.generate_presigned_url('get_object',
                                                   Params={'Bucket': bucket, 'Key': obj},
                                                   ExpiresIn=os.getenv("SIGNED_URL_EXPIRATION", 3600))
  return presigned_url
  
def is_dropframe(timecode):
  assert isinstance(timecode, str), 'The timecode must be a string'
  assert len(timecode) == 11, 'the timecode must be in the format 00:00:00;00'

  # pattern = '^([0-1][0-9]|[0-2][0-3]):([0-5][0-9]):([0-5][0-9]);([0-6][0-9])$'
  pattern = '^([0-0][0-9]):([0-9][0-9]):([0-9][0-9]);([0-9][0-9])$'
  if re.match(pattern, timecode):
    return True
  else:
    return False

def pal_frames_to_tc(total_frames):
  
  totalFrames = float(total_frames)
  totalSeconds = totalFrames/25.00
  totalMinutes = totalSeconds/60
  h = int(totalMinutes / 60)
  m = int(Decimal(totalMinutes) % 60)
  s = int(Decimal(totalSeconds) % 60)
  f = int(Decimal(totalFrames) % 25)

  return(f"{h:02d}:{m:02d}:{s:02d}:{f:02d}")
  
def frames_to_tc(total_frames, drop_frame, frame_rate):
  FRAMES_PER_ONE = ((30 * 60) - 2)
  FRAMES_PER_TEN = ((30 * 60 * 10 - 18))

  frames_left = total_frames
  if drop_frame:
    tc = "{:02d}:{:02d}:{:02d};{:02d}"
    hour = frames_left // (3600 * frame_rate - 108)
    frames_left = frames_left - (hour * (3600 * frame_rate - 108))
    tens = frames_left // FRAMES_PER_TEN
    frames_left = frames_left- (tens * FRAMES_PER_TEN)
    if frames_left >= 2:
      ones = (frames_left - 2) // FRAMES_PER_ONE
    else:
      ones = 0
    frames_left = frames_left - (ones * FRAMES_PER_ONE)
    min = tens * 10 + ones
    sec = frames_left // frame_rate
    frames = frames_left - (sec * frame_rate)
  else:
    tc = "{:02d}:{:02d}:{:02d}:{:02d}"
    hour = frames_left // (3600 * frame_rate)
    frames_left = frames_left - (hour * 3600 * frame_rate)
    min = frames_left // (60 * frame_rate)
    frames_left = frames_left - (min * (60 * frame_rate))
    sec = frames_eft // frame_rate
    frames = frames_left - (sec * frame_rate)

  return tc.format(hour, min, sec, frames)  
    
def tc_to_frames(timecode, drop_frame, frame_rate):
  tc = re.search("(\d{2}):(\d{2}):(\d{2}).(\d{2})", timecode)
  hours = int(tc.group(1))
  minutes = int(tc.group(2))
  seconds = int(tc.group(3))
  frames = int(tc.group(4))
  
  total_frames = 3600 * frame_rate * hours + 60 * frame_rate * minutes  + frame_rate * seconds + frames
  # Drop Frame Compensation
  if drop_frame:
    total_min = 60 * hours + minutes + seconds // 60 + frames // 1800
    total_frames = total_frames - 2 * (total_min - total_min // 10)

  return total_frames
  
def get_content(**kwargs):
  s3uri = os.getenv("CONTENTPORTAL_S3URI_UUID")
  attr = {s3uri: kwargs.get("s3uri", "")}
  return {
    "houseId": kwargs.get("houseId",""),
    "fileName": kwargs.get("fileName", ""),
    "format": kwargs.get("format", "MXF"),
    "fileSize": kwargs.get("fileSize", 0),
    "title": kwargs.get("title", ""),
    "registrationStatus": kwargs.get("registrationStatus", "registered"),
    "type": kwargs.get("type", "clip"),
    "videoStream": {
        "start": kwargs.get("som", "00:00:00;00%00SD"),
        "customStart": kwargs.get("som", "00:00:00;00%00SD"),
        "duration": kwargs.get("dur", "00:00:00;01%00SD"),
        "customDuration": kwargs.get("dur", "00:00:00;01%00SD"),
        "frameRate": kwargs.get("frameRate", "smpte30d"),
        "width": kwargs.get("width", 0),
        "height": kwargs.get("height", 0),
        "bitRate": kwargs.get("bitRate", 0)
    },
    "customAttributes": attr
}

