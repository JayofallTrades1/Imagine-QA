import base64
import json
import logging
import os
import urllib.request
import boto3

logging_level = os.getenv("LOGGING", logging.INFO)
logger = logging.getLogger()
logger.setLevel(logging_level)
logging.getLogger("boto3").setLevel(logging.CRITICAL)
logging.getLogger("botocore").setLevel(logging.CRITICAL)
logging.getLogger("urllib3").setLevel(logging.CRITICAL)

def lambda_handler(event, context):
    #
    # NOTE: THis lambda does NOT take a S3 trigger, must be invoke from another lambda

    src_key = event["key"]
    src_bucket = event["bucket"]
    drop_frame = event["dropFrame"]
        
    # Split path and filename
    src_path, src_name = os.path.split(src_key)
    src_name_noext = os.path.splitext(src_name)[0]

    # Enviroment variables
    region = os.getenv("LAMBDA_REGION")
    account = os.getenv("LAMBDA_ACCOUNT")
    role = os.getenv("ROLE_MEDIACONVERT_ARN")
    endpoint = os.getenv("ENDPOINT_MEDIACONVERT")
    dst = os.getenv("BUCKET_LOWRES")

    # Source and Destination buckets
    src = f"s3://{src_bucket}/{src_key}"
    dst = f"s3://{dst}/{src_name_noext}/stream"
    logger.debug(f"Source:{src}, Destination:{dst}")

    try:
      # Create MediaConvert job
      data = createjob_data(src, dst)
      client_mediaconvert = boto3.client("mediaconvert", endpoint_url=endpoint)
      response = client_mediaconvert.create_job(
          Queue = f"arn:aws:mediaconvert:{region}:{account}:queues/Default",
          Role = role,
          Settings = data,
          #Tags = {"Author":"Imagine Communications"}
          )
      logger.debug(response)
    except Exception as err:
      logger.critical("CreateJob MediaConvert Dash Failed, because %s", str(err))
      raise Exception("createjob-mediaconvert-dash: " + str(err))
      
    return {"JobId": response["Job"]["Id"]}

def createjob_data(src, dst):
    data = {
  "TimecodeConfig": {
    "Source": "EMBEDDED"
  },
  "OutputGroups": [
    {
      "CustomName": "DASHTEST2",
      "Name": "DASH ISO",
      "Outputs": [
        {
          "ContainerSettings": {
            "Container": "MPD"
          },
          "VideoDescription": {
            "Width": 640,
            "ScalingBehavior": "DEFAULT",
            "Height": 360,
            "VideoPreprocessors": {
              "Deinterlacer": {
                "Algorithm": "INTERPOLATE",
                "Mode": "DEINTERLACE",
                "Control": "NORMAL"
              }
            },
            "TimecodeInsertion": "PIC_TIMING_SEI",
            "AntiAlias": "ENABLED",
            "Sharpness": 50,
            "CodecSettings": {
              "Codec": "H_264",
              "H264Settings": {
                "InterlaceMode": "PROGRESSIVE",
                "ParNumerator": 1,
                "NumberReferenceFrames": 3,
                "Syntax": "DEFAULT",
                "FramerateDenominator": 1001,
                "GopClosedCadence": 1,
                "HrdBufferInitialFillPercentage": 90,
                "GopSize": 90,
                "Slices": 1,
                "GopBReference": "ENABLED",
                "HrdBufferSize": 2400000,
                "SlowPal": "DISABLED",
                "ParDenominator": 1,
                "SpatialAdaptiveQuantization": "ENABLED",
                "TemporalAdaptiveQuantization": "ENABLED",
                "FlickerAdaptiveQuantization": "ENABLED",
                "EntropyEncoding": "CABAC",
                "Bitrate": 1200000,
                "FramerateControl": "SPECIFIED",
                "RateControlMode": "CBR",
                "CodecProfile": "MAIN",
                "Telecine": "NONE",
                "FramerateNumerator": 30000,
                "MinIInterval": 0,
                "AdaptiveQuantization": "MEDIUM",
                "CodecLevel": "LEVEL_3_1",
                "FieldEncoding": "PAFF",
                "SceneChangeDetect": "ENABLED",
                "QualityTuningLevel": "MULTI_PASS_HQ",
                "FramerateConversionAlgorithm": "DUPLICATE_DROP",
                "UnregisteredSeiTimecode": "DISABLED",
                "GopSizeUnits": "FRAMES",
                "ParControl": "SPECIFIED",
                "NumberBFramesBetweenReferenceFrames": 3,
                "RepeatPps": "DISABLED"
              }
            },
            "AfdSignaling": "NONE",
            "DropFrameTimecode": "ENABLED",
            "RespondToAfd": "NONE",
            "ColorMetadata": "INSERT"
          },
          "NameModifier": "video"
        },
        {
          "ContainerSettings": {
            "Container": "MPD"
          },
          "AudioDescriptions": [
            {
              "AudioTypeControl": "FOLLOW_INPUT",
              "AudioSourceName": "Audio Selector 1",
              "CodecSettings": {
                "Codec": "AAC",
                "AacSettings": {
                  "AudioDescriptionBroadcasterMix": "NORMAL",
                  "Bitrate": 96000,
                  "RateControlMode": "CBR",
                  "CodecProfile": "LC",
                  "CodingMode": "CODING_MODE_2_0",
                  "RawFormat": "NONE",
                  "SampleRate": 48000,
                  "Specification": "MPEG4"
                }
              },
              "LanguageCodeControl": "FOLLOW_INPUT"
            }
          ],
          "NameModifier": "audio"
        },
        {
          "ContainerSettings": {
            "Container": "MPD"
          },
          "NameModifier": "captions",
          "CaptionDescriptions": [
            {
              "CaptionSelectorName": "Captions Selector 1",
              "DestinationSettings": {
                "DestinationType": "WEBVTT"
              }
            }
          ]
        }
      ],
      "OutputGroupSettings": {
        "Type": "DASH_ISO_GROUP_SETTINGS",
        "DashIsoGroupSettings": {
          "SegmentLength": 30,
          "Destination": dst,
          "FragmentLength": 2,
          "SegmentControl": "SEGMENTED_FILES",
          "MpdProfile": "MAIN_PROFILE",
          "HbbtvCompliance": "NONE"
        }
      }
    }
  ],
  "AdAvailOffset": 0,
  "Inputs": [
    {
      "AudioSelectors": {
        "Audio Selector 1": {
          "Offset": 0,
          "DefaultSelection": "DEFAULT",
          "SelectorType": "TRACK",
          "ProgramSelection": 1
        }
      },
      "VideoSelector": {
        "ColorSpace": "FOLLOW",
        "Rotate": "DEGREE_0",
        "AlphaBehavior": "DISCARD"
      },
      "FilterEnable": "AUTO",
      "PsiControl": "USE_PSI",
      "FilterStrength": 0,
      "DeblockFilter": "DISABLED",
      "DenoiseFilter": "DISABLED",
      "TimecodeSource": "EMBEDDED",
      "CaptionSelectors": {
        "Captions Selector 1": {
          "SourceSettings": {
            "SourceType": "EMBEDDED",
            "EmbeddedSourceSettings": {
              "Source608ChannelNumber": 1,
              "Source608TrackNumber": 1,
              "Convert608To708": "DISABLED",
              "TerminateCaptions": "END_OF_INPUT"
            }
          }
        }
      },
      "FileInput": src
    }
  ]
}
    return data